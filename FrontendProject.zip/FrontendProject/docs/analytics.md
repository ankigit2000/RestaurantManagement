# Analytics

This project does not come with any analytics library.
Should you decide to use one, you may want to consider [Angulartics2](https://github.com/angulartics/angulartics2).

