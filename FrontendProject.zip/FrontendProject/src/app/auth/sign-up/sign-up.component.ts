import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
})
export class SignUpComponent implements OnInit {
  signUpForm!: FormGroup;
  formSubmitted = false;
  showLoginModalFlag = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthenticationService) {}

  ngOnInit() {
    this.signUpForm = this.formBuilder.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      roleId: ['', Validators.required],
    });
  }

  onSubmit() {
    this.formSubmitted = true;
    if (this.signUpForm.invalid) {
      return;
    } else {
      // call register method of authentication service
      const registerContext = {
        Name: this.signUpForm.value.username,
        Password: this.signUpForm.value.password,
        Email: this.signUpForm.value.email,
        RoleId: this.signUpForm.value.roleId,
      };
      console.log('registerContext:', registerContext);
      this.authService.register(this.signUpForm.value).subscribe(
        (response) => {
          window.alert('Sign Up Successful');
          this.router.navigate(['/login']);
        },
        (error) => {
          console.log(error);
          window.alert('Sign Up Failed');
        }
      );
    }
    console.log(this.signUpForm.value);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }
  showLoginModal() {
    this.showLoginModalFlag = false;
    this.router.navigate(['/login']);
  }
}
