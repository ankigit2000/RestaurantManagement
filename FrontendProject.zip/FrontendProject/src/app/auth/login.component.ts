import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { finalize } from 'rxjs/operators';

import { environment } from '@env/environment';
import { Logger, UntilDestroy, untilDestroyed } from '@shared';
import { AuthenticationService } from './authentication.service';
import { CredentialsService } from './credentials.service';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
const log = new Logger('Login');

@UntilDestroy()
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  isLoading = false;
  errorMessage = '';
  type: string = 'password';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private toastr: ToastrService,
    private credentialsService: CredentialsService,
    private authService: AuthenticationService
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  get username() {
    return this.loginForm.get('username');
  }

  get password() {
    return this.loginForm.get('password');
  }

  login() {
    const credentials = this.loginForm.value;

    const apiUrl = `${environment.serverUrl}/Auth/login`;
    const requestBody = {
      username: credentials.username,
      password: credentials.password,
    };

    this.authService.login(requestBody).subscribe(
      (response: any) => {
        // Success response from API
        const credentialObj = {
          username: credentials.username,
          token: response.token,
          //usertype: response.usertype // assuming this is the user type returned by the API
        };
        console.log(credentialObj);
        this.credentialsService.setCredentials(credentialObj);
        this.errorMessage = '';
        // this.toastr.success('Login successful');
        this.router.navigate(['/home']);
        // if (credentialObj.usertype === 'admin') {
        //   this.router.navigate(['/adminHome']);
        // } else {
        //   this.router.navigate(['/userHome']);
        // }
      },
      (error) => {
        // Error response from API
        this.errorMessage = 'Incorrect username or password';
        this.toastr.error(this.errorMessage);
      }
    );
  }
}

// login() {
//   const credentials = this.loginForm.value;

//   const apiUrl = `${environment.serverUrl}/api/login`;
//   const requestBody = {
//     username: credentials.username,
//     password: credentials.password
//   };

//   this.http.post(apiUrl, requestBody).subscribe(
//     (response) => {
//       // Success response from API
//       this.errorMessage = '';
//       // set access toke
//       // check user role
//       // according to role navigate to user home page or admin hom epage
//       this.router.navigate(['/restaurantList']);
//       alert('Login Successful');
//     },
//     (error) => {
//       // Error response from API
//       this.errorMessage = 'Incorrect username or password';
//     }
//   );
// }

// export class LoginComponent implements OnInit {
//   version: string | null = environment.version;
//   loginForm!: FormGroup;
//   isLoading = false;
//   //errorMessage = '';
//   //type: string = 'password';
//   error: string | undefined;
//   errTrue: boolean | undefined;

//   constructor(
//     private router: Router,
//     private route: ActivatedRoute,
//     private formBuilder: FormBuilder,
//     private authenticationService: AuthenticationService,
//     private _credentialService: CredentialsService,
//     private toastr: ToastrService
//   ) //fb: FormBuilder
//   {
//     this.createForm();
//   }

//   ngOnInit() {}

//   login() {
//     if (this.loginForm.valid) {
//       this.isLoading = true;
//       const reqObj = {
//         username: this.loginForm.value.username,
//         password: this.loginForm.value.password,
//       };
//       this.authenticationService.login(reqObj)
//       .subscribe(
//         (response: any) => {
//           this.isLoading = false;
//           this._credentialService.setCredentials(response);
//           this.toastr.success('Login successfull');
//           if (response.usertype == 1) {
//             this.router.navigate(['/home']);
//           }
//           if (response.usertype == 2) {
//             this.router.navigate(['/userhome']);
//           }
//         },
//         (error: any) => {
//           this.isLoading = false;
//           this.errTrue = true;
//           console.log('error', error);
//           log.error('error occured', error);
//         }
//       );
//     }
//   }

//   private createForm() {
//     this.loginForm = this.formBuilder.group({
//       username: ['', Validators.required],
//       password: ['', Validators.required],
//     });
//   }
// }

// export class LoginComponent implements OnInit {
//   loginForm!: FormGroup;
//   isLoading = false;
//   errorMessage = '';
//   type: string = 'password';

//   constructor(
//     private router: Router,
//     private route: ActivatedRoute,
//     private formBuilder: FormBuilder,
//     private authenticationService: AuthenticationService,
//     fb: FormBuilder
//   ) {}

//   ngOnInit() {
//     this.loginForm = this.formBuilder.group({
//       username: ['', Validators.required],
//       password: ['', Validators.required],
//     });
//   }

//   get username() {
//     return this.loginForm.get('username');
//   }

//   get password() {
//     return this.loginForm.get('password');
//   }

//   login() {
//     const credentials = this.loginForm.value;

//     if (credentials.username === 'user' && credentials.password === 'pass') {
//       this.errorMessage = '';
//       this.router.navigate(['/restaurantList']);
//       alert('Login Successful');
//     } else {
//       this.errorMessage = 'Incorrect username or password';
//     }
//   }
// }
