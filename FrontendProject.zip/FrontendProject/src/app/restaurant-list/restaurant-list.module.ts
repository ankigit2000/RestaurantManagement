import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbRatingModule } from '@ng-bootstrap/ng-bootstrap';

import { RestaurantListRoutingModule } from './restaurant-list-routing.module';
import { RestaurantListComponent } from './restaurant-list.component';
import { RestaurantCardComponent } from './components/restaurant-card/restaurant-card.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RestaurantDetailsComponent } from './components/restaurant-details/restaurant-details.component';
import { AddRestaurantComponent } from './components/add-restaurant/add-restaurant.component';
import { SharedModule } from '@app/@shared';
import { EditRestaurantComponent } from './components/edit-restaurant/edit-restaurant.component';

@NgModule({
  declarations: [
    RestaurantListComponent,
    RestaurantCardComponent,
    RestaurantDetailsComponent,
    AddRestaurantComponent,
    EditRestaurantComponent,
  ],
  imports: [CommonModule, NgbRatingModule, FormsModule, ReactiveFormsModule, RestaurantListRoutingModule, SharedModule],
  exports: [RestaurantListComponent, RestaurantCardComponent],
})
export class RestaurantListModule {}
