import { TestBed } from '@angular/core/testing';

import { RestaurantListDALService } from './restaurant-list-dal.service';

describe('RestaurantListDALService', () => {
  let service: RestaurantListDALService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RestaurantListDALService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
