import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RestaurantListDALService } from './restaurant-list-dal.service';
export const random = (min: any = 1, max: any = 9999999) => Math.floor(Math.random() * (max - min)) + min;

@Injectable({
  providedIn: 'root',
})
export class RestaurantListService {
  constructor(private restaurantDALService: RestaurantListDALService) {}
  /**
   * Method to get the restaurants list
   * @returns restaurants list
   */
  getRestaurants(searchString: string): Observable<any> {
    return new Observable((observer) => {
      this.restaurantDALService.fetchRestaurants(searchString).subscribe({
        next: (data) => {
          observer.next(this.formatRestaurants(data));
        },
        error: (error) => {
          observer.error(error);
        },
      });
    });
  }
  addRestaurant(value: any): Observable<any> {
    value.id = random();
    value.location = value.city + ' ' + value.state;
    return this.restaurantDALService.addRestaurant(value);
  }
  updateRestaurant(id: string, value: any): Observable<any> {
    value.location = value.city + ' ' + value.state;
    return this.restaurantDALService.updateRestaurantById(id, value);
  }
  fetchRestaurantById(id: string): Observable<any> {
    return new Observable((observer) => {
      this.restaurantDALService.fetchRestaurantById(id).subscribe({
        next: (data) => {
          observer.next(data);
        },
      });
    });
  }
  deleteRestaurant(id: string): Observable<any> {
    return this.restaurantDALService.deleteRestaurant(id);
  }
  getMenuItems(id: string, type: string): Observable<any> {
    return this.restaurantDALService.getMenuItems(id, type);
  }
  /**
   * Method to format the restaurants data
   * @param restaurantList restaurants list
   * @returns formatted restaurants list
   */
  private formatRestaurants(restaurantList: any): any {
    return restaurantList;
  }
}
