﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface IRestaurantDetailsService
    {
        Task<IEnumerable<RestaurantDetails>> GetAllAsync();
        Task<RestaurantDetails> GetAsync(int id);

        Task<RestaurantDetails> AddAsync(RestaurantDetails restaurantDetails);

        Task<RestaurantDetails> DeleteAsync(int id);

        Task<RestaurantDetails> UpdateAsync(int id, RestaurantDetails updated);
    }
}
