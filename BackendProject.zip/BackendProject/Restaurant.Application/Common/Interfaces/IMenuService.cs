﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface IMenuService
    {
        Task<IEnumerable<RestaurantMenu>> GetAllAsync();
        Task<RestaurantMenu> GetAsync(int id);

        Task<RestaurantMenu> AddAsync(RestaurantMenu menuItem);

        Task<RestaurantMenu> DeleteAsync(int id);

        Task<RestaurantMenu> UpdateAsync(int id, RestaurantMenu updated);
    }
}
