﻿using DocumentFormat.OpenXml.Spreadsheet;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class MenuItemTypeService : IMenuItemTypeService
    {
        private readonly IMenuItemTypeRepository _menuItemTypeRepository;

        public MenuItemTypeService(IMenuItemTypeRepository menuItemTypeRepository)
        {
            this._menuItemTypeRepository = menuItemTypeRepository;
        }
        public async Task<RestaurantMenuItemType> AddAsync(RestaurantMenuItemType menuItemType)
        {
            return await _menuItemTypeRepository.AddAsync(menuItemType);
        }

        public async Task<RestaurantMenuItemType> DeleteAsync(int id)
        {
            return await _menuItemTypeRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantMenuItemType>> GetAllAsync()
        {
            return await _menuItemTypeRepository.GetAllAsync();
        }

        public async Task<RestaurantMenuItemType> GetAsync(int id)
        {
            return await _menuItemTypeRepository.GetAsync(id);
        }

        public async Task<RestaurantMenuItemType> UpdateAsync(int id, RestaurantMenuItemType updated)
        {
            return await _menuItemTypeRepository.UpdateAsync(id, updated);
        }
    }
}
