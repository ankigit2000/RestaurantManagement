﻿using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.IdentityModel.Tokens;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class TokenHandlerService : ITokenHandlerService
    {
        private readonly ITokenHandler _tokenHandler;
        public TokenHandlerService(ITokenHandler _tokenHandler)
        {
            this._tokenHandler = _tokenHandler;
        }
        public Task<string> CreateTokenAsync(Domain.Entities.Users User)
        {
            return _tokenHandler.CreateTokenAsync(User);
        }
    }
}
