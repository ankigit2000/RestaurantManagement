﻿using Moq;
using Restaurant.Application.Common.Services;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace RestaurantManagement.Test.Restaurant.Application.Test
{
    public class TestCityServices
    {
        private readonly ICityRepository _cityRepositoryMock;
        private readonly CityService _cityService;

        public TestCityServices()
        {
            _cityRepositoryMock = Mock.Of<ICityRepository>();
            _cityService = new CityService(_cityRepositoryMock);
        }

        [Fact]
        public async Task AddAsync_AddsCity()
        {
            var city = new RestaurantCity { CityName = "TestCity" };
            Mock.Get(_cityRepositoryMock)
                .Setup(repo => repo.AddAsync(city))
                .ReturnsAsync(city);
            var result = await _cityService.AddAsync(city);
            Assert.Equal(city, result);
        }

        [Fact]
        public async Task DeleteAsync_DeletesCity()
        {
            var city = new RestaurantCity { CityName = "TestCity" };
            Mock.Get(_cityRepositoryMock)
                .Setup(repo => repo.DeleteAsync(1))
                .ReturnsAsync(city);

            var result = await _cityService.DeleteAsync(1);
            Assert.Equal(city, result);
        }

        [Fact]
        public async Task GetAllAsync_ReturnsAllCities()
        {
            var cities = new List<RestaurantCity>
            {
                new RestaurantCity { CityName = "City1" },
                new RestaurantCity { CityName = "City2" }
            };
            Mock.Get(_cityRepositoryMock)
                .Setup(repo => repo.GetAllAsync())
                .ReturnsAsync(cities);
            var result = await _cityService.GetAllAsync();
            Assert.Equal(cities, result);
        }

        [Fact]
        public async Task GetAsync_ReturnsCity()
        {
            var city = new RestaurantCity { CityName = "TestCity" };
            Mock.Get(_cityRepositoryMock)
                .Setup(repo => repo.GetAsync(1))
                .ReturnsAsync(city);
            var result = await _cityService.GetAsync(1);
            Assert.Equal(city, result);
        }

        [Fact]
        public async Task UpdateAsync_UpdatesCity()
        {
            var city = new RestaurantCity { CityName = "TestCity" };
            var updatedCity = new RestaurantCity { CityName = "UpdatedCity" };
            Mock.Get(_cityRepositoryMock)
                .Setup(repo => repo.UpdateAsync(1, updatedCity))
                .ReturnsAsync(updatedCity);
            var result = await _cityService.UpdateAsync(1, updatedCity);
            Assert.Equal(updatedCity, result);
        }
    }
}
            

