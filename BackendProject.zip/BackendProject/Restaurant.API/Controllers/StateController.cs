﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;
using System.IO.Compression;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StateController : Controller
    {
        private readonly IStateService stateService;
        private readonly IMapper mapper;

        public StateController(IStateService stateService, IMapper mapper)
        {
            this.stateService = stateService;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllStatesAsync()
        {
            var states = await stateService.GetAllAsync();
            return Ok(states);

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetStatesAsync")]
        public async Task<IActionResult> GetStatesAsync(int id)
        {
            var state = await stateService.GetAsync(id);

            if (state == null)
            {
                return NotFound();
            }
            return Ok(state);
        }

        [HttpPost]
        public async Task<IActionResult> AddStatesAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantState addRestaurantState)
        {

            var state = new Restaurant.Domain.Entities.RestaurantState()
            {

                StateName= addRestaurantState.StateName,
                Zipcode=addRestaurantState.Zipcode,
                UpdatedBy = addRestaurantState.UpdatedBy,
                UpdatedDate = addRestaurantState.UpdatedDate

            };

            state = await stateService.AddAsync(state);

            var stateDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantState
            {
                StateID = state.StateID,
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate

            };
            return CreatedAtAction(nameof(GetStatesAsync), new { id = stateDTO.StateID }, stateDTO);

        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeletestatesAsync(int id)
        {

            var state = await stateService.DeleteAsync(id);


            if (state == null)
            {
                return NotFound();
            }
            var stateDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantState
            {
                StateID = state.StateID,
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate
            };

            return Ok(stateDTO);
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedCityAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantState updateRestaurantState)
        {
            var state = new Restaurant.Domain.Entities.RestaurantState()
            {
                StateName = updateRestaurantState.StateName,
                Zipcode = updateRestaurantState.Zipcode,
                UpdatedBy = updateRestaurantState.UpdatedBy,
                UpdatedDate = updateRestaurantState.UpdatedDate

            };
            state = await stateService.UpdateAsync(id, state);
            if (state == null)
            {
                return NotFound();
            }
            var stateDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantState()
            {
                StateID = state.StateID,
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate
            };
            return Ok(stateDTO);
        }
    }
}
