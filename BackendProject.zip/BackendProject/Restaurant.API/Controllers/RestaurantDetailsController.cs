﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RestaurantDetailsController : Controller
    {
        private readonly IRestaurantDetailsService restaurantDetailsService;
        private readonly IMapper mapper;

        public RestaurantDetailsController(IRestaurantDetailsService restaurantDetailsService, IMapper mapper)
        {
            this.restaurantDetailsService = restaurantDetailsService;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllRestaurantsAsync()
        {
            var restaurants = await restaurantDetailsService.GetAllAsync();
            return Ok(restaurants);

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetRestaurantsAsync")]
        public async Task<IActionResult> GetRestaurantsAsync(int id)
        {
            var restaurant = await restaurantDetailsService.GetAsync(id);

            if (restaurant == null)
            {
                return NotFound();
            }
            return Ok(restaurant);
        }

        [HttpPost]
        public async Task<IActionResult> AddRestaurantsAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantDetails addRestaurantDetails)
        {
            var restaurants = new Restaurant.Domain.Entities.RestaurantDetails()
            {
                Restaurant = addRestaurantDetails.Restaurant,
                Specialities= addRestaurantDetails.Specialities,
                AdditionalFeatures = addRestaurantDetails.AdditionalFeatures,
                LocationID = addRestaurantDetails.LocationID,
                MenuID= addRestaurantDetails.MenuID,
                UserID= addRestaurantDetails.UserID, 
                UpdatedBy = addRestaurantDetails.UpdatedBy,
                UpdatedDate = addRestaurantDetails.UpdatedDate

            };
            restaurants = await restaurantDetailsService.AddAsync(restaurants);
            var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails
            {
                RestaurantID = restaurants.RestaurantID,
                Restaurant = restaurants.Restaurant,
                Specialities = restaurants.Specialities,
                AdditionalFeatures = restaurants.AdditionalFeatures,
                LocationID = restaurants.LocationID,
                MenuID = restaurants.MenuID,
                UserID = restaurants.UserID,
                UpdatedBy = restaurants.UpdatedBy,
                UpdatedDate = restaurants.UpdatedDate

            };
            return CreatedAtAction(nameof(GetRestaurantsAsync), new { id = restaurantDTO.RestaurantID }, restaurantDTO);

        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteRestaurantsAsync(int id)
        {
            var restaurant = await restaurantDetailsService.DeleteAsync(id);
            if (restaurant == null)
            {
                return NotFound();
            }
            var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails
            {
                RestaurantID = restaurant.RestaurantID,
                Restaurant = restaurant.Restaurant,
                Specialities = restaurant.Specialities,
                AdditionalFeatures = restaurant.AdditionalFeatures,
                UpdatedBy = restaurant.UpdatedBy,
                UpdatedDate = restaurant.UpdatedDate
            };
            return Ok(restaurantDTO);
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedRestaurantAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantDetails updateRestaurantDetails)
        {
            var restaurant = new Restaurant.Domain.Entities.RestaurantDetails()
            {
                Restaurant = updateRestaurantDetails.Restaurant,
                Specialities = updateRestaurantDetails.Specialities,
                AdditionalFeatures = updateRestaurantDetails.AdditionalFeatures,
                UpdatedBy = updateRestaurantDetails.UpdatedBy,
                UpdatedDate = updateRestaurantDetails.UpdatedDate

            };
            restaurant = await restaurantDetailsService.UpdateAsync(id, restaurant);
            if (restaurant == null)
            {
                return NotFound();
            }
            var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails()
            {
               RestaurantID= restaurant.RestaurantID,
                Restaurant = restaurant.Restaurant,
                Specialities = restaurant.Specialities,
                AdditionalFeatures = restaurant.AdditionalFeatures,
                UpdatedBy = restaurant.UpdatedBy,
                UpdatedDate = restaurant.UpdatedDate
            };
            return Ok(restaurantDTO);
        }
    }
}
