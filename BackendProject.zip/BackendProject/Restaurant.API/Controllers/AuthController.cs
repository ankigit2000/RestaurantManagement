﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly IUserService userService;
        private readonly ITokenHandlerService tokenHandlerService;

        public AuthController(IUserService _userRepository, ITokenHandlerService _tokenHandlerSevice)
        {
            this.userService = _userRepository;
            this.tokenHandlerService = _tokenHandlerSevice;

        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> LoginAsync(Login login)
        {
            var user = await userService.AuthenticateAsync(login.username, login.password);

            if (user == null)
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }

            var token = await tokenHandlerService.CreateTokenAsync(user);

            return Ok(new
            {
                token = token,
                Message = "Login Success!",
                RoleId = user.RoleID,


            });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register register)
        {
            var userExists = await userService.FindByNameAsync(register.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User already exists!" });

            var result = await userService.RegisterAsync(register.Username, register.Email, register.Password, register.RoleId);
            var user = await userService.AuthenticateAsync(register.Username, register.Password);

            if (result == null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User creation failed! Please check user details and try again." });

            return Ok(new
            {
                Id = user.UserID,
                Username = user.UserName,
                Email = user.Email,
                Password = register.Password,
                Message = "User created successfully!"
            });
        }
    }
}