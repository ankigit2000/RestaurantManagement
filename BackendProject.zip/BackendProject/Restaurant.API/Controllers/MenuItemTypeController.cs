﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MenuItemTypeController : Controller
    {
        private readonly IMenuItemTypeService _MenuItemTypeService;
        private readonly ILoggerManager _logger;
        private readonly IMapper mapper;

        public MenuItemTypeController(IMenuItemTypeService _MenuItemTypeService, IMapper mapper, ILoggerManager _logger)
        {
            this._MenuItemTypeService = _MenuItemTypeService;
            this._logger = _logger;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllMenyItemTypeAsync()
        {
            try
            {
                var menuItemTypes = await _MenuItemTypeService.GetAllAsync();
                _logger.LogInfo("Called Get all MenuItemTypes ");
                return Ok(menuItemTypes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetMenyItemTypeAsync")]
        public async Task<IActionResult> GetMenyItemTypeAsync(int id)
        {
            try
            {
                var menuItemTypes = await _MenuItemTypeService.GetAsync(id);

                if (menuItemTypes == null)
                {
                    return NotFound();
                }
                _logger.LogInfo("Called Get MenuItemTypes by ID ");
                return Ok(menuItemTypes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddMenuItemsTypeAsync(Restaurant.Infrastructure.Persistance.DTO.AddMenuItemType addMenuItemType)
        {
            try
            {
                var menuItemTypes = new Restaurant.Domain.Entities.RestaurantMenuItemType()
                {
                   ItemType=addMenuItemType.ItemType,
                    UpdatedBy = addMenuItemType.UpdatedBy,
                    UpdatedDate = addMenuItemType.UpdatedDate
                };

                menuItemTypes = await _MenuItemTypeService.AddAsync(menuItemTypes);

                var MenuItemTypeDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItemType
                {
                    MenuItemTypeID = menuItemTypes.MenuItemTypeID,
                    ItemType=menuItemTypes.ItemType,
                    UpdatedBy = menuItemTypes.UpdatedBy,
                    UpdatedDate = menuItemTypes.UpdatedDate
                };
                _logger.LogInfo("MenuItemType Created");
                return CreatedAtAction(nameof(GetMenyItemTypeAsync), new { id = MenuItemTypeDTO.MenuItemTypeID }, MenuItemTypeDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteMenuItemTypeAsync(int id)
        {
            try
            {
                var menuItemTypes = await _MenuItemTypeService.DeleteAsync(id);
                if (menuItemTypes == null)
                {
                    return NotFound();
                }
                var MenuItemTypeDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItemType
                {
                    MenuItemTypeID = menuItemTypes.MenuItemTypeID,
                    ItemType = menuItemTypes.ItemType,
                    UpdatedBy = menuItemTypes.UpdatedBy,
                    UpdatedDate = menuItemTypes.UpdatedDate
                };
                _logger.LogInfo("Deleted MenuItemType by ID ");
                return Ok(MenuItemTypeDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedMenuItemTypeyAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateMenuItemType updateMenuItemTypet)
        {
            try
            {
                var menuItemType = new Restaurant.Domain.Entities.RestaurantMenuItemType()
                {
                    ItemType = updateMenuItemTypet.ItemType,
                    UpdatedBy = updateMenuItemTypet.UpdatedBy,
                    UpdatedDate = updateMenuItemTypet.UpdatedDate

                };
                menuItemType = await _MenuItemTypeService.UpdateAsync(id, menuItemType);
                if (menuItemType == null)
                {
                    return NotFound();
                }
                var MenuItemTypeDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItemType()
                {
                    MenuItemTypeID = menuItemType.MenuItemTypeID,
                    ItemType = menuItemType.ItemType,
                    UpdatedBy = menuItemType.UpdatedBy,
                    UpdatedDate = menuItemType.UpdatedDate
                };
                _logger.LogInfo("Updated City");
                return Ok(MenuItemTypeDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

    }
}
