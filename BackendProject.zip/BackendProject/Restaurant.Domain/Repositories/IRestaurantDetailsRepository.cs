﻿using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Repositories
{
    public interface IRestaurantDetailsRepository : IRepository<Restaurant.Domain.Entities.RestaurantDetails>
    {
        /*Task<IEnumerable<RestaurantDetails>> GetAllAsync();
        Task<RestaurantDetails> GetAsync(int id);

        Task<RestaurantDetails> AddAsync(RestaurantDetails restaurantDetails);

        Task<RestaurantDetails> DeleteAsync(int id);

        Task<RestaurantDetails> UpdateAsync(int id, RestaurantDetails updated);*/
    }
}
