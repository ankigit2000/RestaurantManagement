﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class Users
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }
        [MaxLength(50)]
        public string Password { get; set; }
        public string Email { get; set; }
        public int RoleID { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        [ForeignKey("RoleID")]
        public  Role Role { get; set; }

        public IEnumerable<RestaurantDetails> RestaurantDetails { get; set; }
        public IEnumerable<User_Roles> User_Role { get; set; }
    }
}
