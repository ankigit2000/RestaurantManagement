﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class RestaurantDetails
    {
        [Key]
        public int RestaurantID { get; set; }
        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }
        public int LocationID { get; set; }
        public int MenuID { get; set; }
        public int UserID { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        [ForeignKey("LocationID")]
        public RestaurantLocation Location { get; set; }
        [ForeignKey("MenuID")]
        public RestaurantMenu Menu { get; set; }
        [ForeignKey("UserID")]
        public Users Users { get; set; }

    }
}
