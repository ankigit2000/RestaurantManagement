﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Restaurant.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Initial10 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BreakFast",
                table: "RestaurantMenuItemType");

            migrationBuilder.DropColumn(
                name: "Dinner",
                table: "RestaurantMenuItemType");

            migrationBuilder.DropColumn(
                name: "ItemType",
                table: "RestaurantMenuItems");

            migrationBuilder.RenameColumn(
                name: "Lunch",
                table: "RestaurantMenuItemType",
                newName: "ItemType");

            migrationBuilder.RenameColumn(
                name: "MenuTypeID",
                table: "RestaurantMenuItemType",
                newName: "MenuItemTypeID");

            migrationBuilder.AlterColumn<string>(
                name: "Password",
                table: "Users",
                type: "nvarchar(225)",
                maxLength: 225,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ItemType",
                table: "RestaurantMenuItemType",
                newName: "Lunch");

            migrationBuilder.RenameColumn(
                name: "MenuItemTypeID",
                table: "RestaurantMenuItemType",
                newName: "MenuTypeID");

            migrationBuilder.AlterColumn<string>(
                name: "Password",
                table: "Users",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(225)",
                oldMaxLength: 225);

            migrationBuilder.AddColumn<string>(
                name: "BreakFast",
                table: "RestaurantMenuItemType",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Dinner",
                table: "RestaurantMenuItemType",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ItemType",
                table: "RestaurantMenuItems",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");
        }
    }
}
