﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Restaurant.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "RestaurantCity",
                columns: table => new
                {
                    CityID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CityName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantCity", x => x.CityID);
                });

            migrationBuilder.CreateTable(
                name: "RestaurantMenuItemType",
                columns: table => new
                {
                    MenuTypeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BreakFast = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Lunch = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Dinner = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantMenuItemType", x => x.MenuTypeID);
                });

            migrationBuilder.CreateTable(
                name: "RestaurantState",
                columns: table => new
                {
                    StateID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StateName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Zipcode = table.Column<int>(type: "int", maxLength: 6, nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantState", x => x.StateID);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    RoleID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.RoleID);
                });

            migrationBuilder.CreateTable(
                name: "RestaurantMenuItems",
                columns: table => new
                {
                    ItemID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ItemType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ItemPrice = table.Column<double>(type: "float", maxLength: 50, nullable: false),
                    MenuItemTypeID = table.Column<int>(type: "int", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantMenuItems", x => x.ItemID);
                    table.ForeignKey(
                        name: "FK_RestaurantMenuItemType_RestaurantMenuItems",
                        column: x => x.MenuItemTypeID,
                        principalTable: "RestaurantMenuItemType",
                        principalColumn: "MenuTypeID");
                });

            migrationBuilder.CreateTable(
                name: "RestaurantLocation",
                columns: table => new
                {
                    LocationID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Address = table.Column<string>(type: "nvarchar(225)", maxLength: 225, nullable: false),
                    CityID = table.Column<int>(type: "int", nullable: false),
                    StateID = table.Column<int>(type: "int", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantLocation", x => x.LocationID);
                    table.ForeignKey(
                        name: "FK_City_Location",
                        column: x => x.CityID,
                        principalTable: "RestaurantCity",
                        principalColumn: "CityID");
                    table.ForeignKey(
                        name: "FK_RestaurantState_RestaurantLocation",
                        column: x => x.CityID,
                        principalTable: "RestaurantState",
                        principalColumn: "StateID");
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RoleID = table.Column<int>(type: "int", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserID);
                    table.ForeignKey(
                        name: "FK_Users_Role",
                        column: x => x.RoleID,
                        principalTable: "Role",
                        principalColumn: "RoleID");
                });

            migrationBuilder.CreateTable(
                name: "RestaurantMenu",
                columns: table => new
                {
                    MenuID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemID = table.Column<int>(type: "int", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantMenu", x => x.MenuID);
                    table.ForeignKey(
                        name: "FK_RestaurantMenuItems_RestaurantMenu",
                        column: x => x.ItemID,
                        principalTable: "RestaurantMenuItems",
                        principalColumn: "ItemID");
                });

            migrationBuilder.CreateTable(
                name: "User_Role",
                columns: table => new
                {
                    UserRolesID = table.Column<int>(name: "User_RolesID", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<int>(type: "int", nullable: false),
                    RoleID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User_Role", x => x.UserRolesID);
                    table.ForeignKey(
                        name: "FK_UserRole_User",
                        column: x => x.UserID,
                        principalTable: "Users",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_User_Role_Role_RoleID",
                        column: x => x.RoleID,
                        principalTable: "Role",
                        principalColumn: "RoleID");
                });

            migrationBuilder.CreateTable(
                name: "RestaurantDetails",
                columns: table => new
                {
                    RestaurantID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Restaurant = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Specialities = table.Column<string>(type: "nvarchar(225)", maxLength: 225, nullable: false),
                    AdditionalFeatures = table.Column<string>(type: "nvarchar(225)", maxLength: 225, nullable: false),
                    LocationID = table.Column<int>(type: "int", nullable: false),
                    MenuID = table.Column<int>(type: "int", nullable: false),
                    UserID = table.Column<int>(type: "int", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RestaurantDetails", x => x.RestaurantID);
                    table.ForeignKey(
                        name: "FK_RestaurantLocation_RestaurantDetails",
                        column: x => x.LocationID,
                        principalTable: "RestaurantLocation",
                        principalColumn: "LocationID");
                    table.ForeignKey(
                        name: "FK_RestaurantMenu_RestaurantDetails",
                        column: x => x.MenuID,
                        principalTable: "RestaurantMenu",
                        principalColumn: "MenuID");
                    table.ForeignKey(
                        name: "FK_Users_RestaurantDetails",
                        column: x => x.UserID,
                        principalTable: "Users",
                        principalColumn: "UserID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantDetails_LocationID",
                table: "RestaurantDetails",
                column: "LocationID");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantDetails_MenuID",
                table: "RestaurantDetails",
                column: "MenuID");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantDetails_UserID",
                table: "RestaurantDetails",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantLocation_CityID",
                table: "RestaurantLocation",
                column: "CityID");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantMenu_ItemID",
                table: "RestaurantMenu",
                column: "ItemID");

            migrationBuilder.CreateIndex(
                name: "IX_RestaurantMenuItems_MenuItemTypeID",
                table: "RestaurantMenuItems",
                column: "MenuItemTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_User_Role_RoleID",
                table: "User_Role",
                column: "RoleID");

            migrationBuilder.CreateIndex(
                name: "IX_User_Role_UserID",
                table: "User_Role",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_Users_RoleID",
                table: "Users",
                column: "RoleID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RestaurantDetails");

            migrationBuilder.DropTable(
                name: "User_Role");

            migrationBuilder.DropTable(
                name: "RestaurantLocation");

            migrationBuilder.DropTable(
                name: "RestaurantMenu");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "RestaurantCity");

            migrationBuilder.DropTable(
                name: "RestaurantState");

            migrationBuilder.DropTable(
                name: "RestaurantMenuItems");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "RestaurantMenuItemType");
        }
    }
}
