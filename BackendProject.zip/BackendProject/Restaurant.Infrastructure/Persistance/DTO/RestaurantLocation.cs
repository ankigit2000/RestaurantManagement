﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.DTO
{
    public class RestaurantLocation
    {
        [Key]
        public int LocationID { get; set; }
        public string Address { get; set; }
        public int CityID { get; set; }
        public int StateID { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        [ForeignKey("CityID")]
        public RestaurantCity City { get; set; }
        [ForeignKey("StateID")]
        public RestaurantState State { get; set; }
        public IEnumerable<RestaurantDetails> RestaurantDetails { get; set; }
    }
}
