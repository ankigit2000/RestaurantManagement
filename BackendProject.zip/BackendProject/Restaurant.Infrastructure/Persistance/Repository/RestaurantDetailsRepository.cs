﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class RestaurantDetailsRepository : Repository <Restaurant.Domain.Entities.RestaurantDetails>,IRestaurantDetailsRepository
    {
       
            private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public RestaurantDetailsRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
