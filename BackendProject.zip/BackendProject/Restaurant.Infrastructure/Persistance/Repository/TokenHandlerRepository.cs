﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class TokenHandlerRepository: ITokenHandler
    {
        private readonly IConfiguration configuration;

        public TokenHandlerRepository(IConfiguration configuration)
        {
            this.configuration = configuration;
        }


        public Task<string> CreateTokenAsync(Users Users)
        {


            var claims = new List<Claim>
        {
            new Claim(ClaimTypes.NameIdentifier, Users.UserID.ToString()),
            new Claim(ClaimTypes.Name, Users.UserName),
            new Claim(ClaimTypes.Role, Users.Role.RoleName)
        };



            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);


            var token = new JwtSecurityToken(
           configuration["Jwt:Issuer"],
           configuration["Jwt:Audience"],
           claims,
           expires: DateTime.Now.AddMinutes(15),
           signingCredentials: credentials);




            return Task.FromResult(new JwtSecurityTokenHandler().WriteToken(token));
        }
    }

}

