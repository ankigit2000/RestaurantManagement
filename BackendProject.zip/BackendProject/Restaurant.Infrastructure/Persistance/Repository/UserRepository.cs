﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class UserRepository: IUserRepository
    {
        private readonly IUnitOfWork _unitOfWork;

        public UserRepository(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Users> AuthenticateAsync(string username, string password)
        {
            var user = await _unitOfWork.RestaurantDetailsDbContext.Users
        .Include(x => x.Role)
        .SingleOrDefaultAsync(x => x.UserName == username);

            if (user == null)
            {
                return null;
            }

            // Check if the provided password matches the hashed password in the database
            if (BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                return user;
            }

            return null;
        }
        public async Task<Users> FindByNameAsync(string username)
        {
            return await _unitOfWork.RestaurantDetailsDbContext.Users
     .FirstOrDefaultAsync(u => u.UserName == username);
        }



        public async Task AddAsync(Users user)
        {
            await _unitOfWork.RestaurantDetailsDbContext.Users.AddAsync(user);
        }

        public async Task<Users> RegisterAsync(string username, string email, string password, int RoleId)
        {
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

            var user = new Users
            {
                UserName = username,
                Email = email,
                Password = hashedPassword,
                RoleID = RoleId
            };

            await AddAsync(user);
            await _unitOfWork.CommitAsync();

            return user;
        }
    }
}


