﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Infrastructure.Persistance.DTO;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Data
{
    public class RestaurantDetailsDbContext : DbContext
    {
        public RestaurantDetailsDbContext(DbContextOptions<RestaurantDetailsDbContext> options) : base(options)
        {

        }
        public DbSet<Domain.Entities.RestaurantDetails> RestaurantDetails { get; set; }
        public DbSet<Domain.Entities.Users> Users { get; set; }
        public DbSet<Domain.Entities.Role> Roles { get; set; }
        public DbSet<Domain.Entities.User_Roles> User_Role { get; set; }
        public DbSet<Domain.Entities.RestaurantCity> City { get; set; }
        public DbSet<Domain.Entities.RestaurantState> State { get; set; }
        public DbSet<Domain.Entities.RestaurantLocation> Location { get; set; }
        public DbSet<Domain.Entities.RestaurantMenuItems> MenuItems { get; set; }
        public DbSet<Domain.Entities.RestaurantMenuItemType> MenuItemTypes { get; set; }
        public DbSet<Domain.Entities.RestaurantMenu> Menu { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(e => e.UserID);
                entity.Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(50);
                entity.Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(225);
                entity.HasOne(e => e.Role)
                .WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_Users_Role");
            });
            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");
                entity.HasKey(e => e.RoleID);
                entity.Property(e => e.RoleName)
                      .IsRequired()
                      .HasMaxLength(50);
            });
            modelBuilder.Entity<Domain.Entities.RestaurantCity>(entity =>
            {
                entity.ToTable("RestaurantCity");
                entity.HasKey(e => e.CityID);
                entity.Property(e => e.CityName)
                      .IsRequired()
                      .HasMaxLength(50);
            });
            modelBuilder.Entity<Domain.Entities.RestaurantState>(entity =>
            {
                entity.ToTable("RestaurantState");
                entity.HasKey(e => e.StateID);
                entity.Property(e => e.StateName)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.Property(e => e.Zipcode)
                      .IsRequired()
                      .HasMaxLength(6);
            });
            modelBuilder.Entity<Domain.Entities.RestaurantLocation>(entity =>
            {
                entity.ToTable("RestaurantLocation");
                entity.HasKey(e => e.LocationID);
                entity.Property(e => e.Address)
                      .IsRequired()
                      .HasMaxLength(225);
                entity.HasOne(e => e.City)
                .WithMany(f => f.Location)
                .HasForeignKey(e => e.CityID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_City_Location");
                entity.HasOne(d => d.State)
               .WithMany(p => p.Location)
               .HasForeignKey(d => d.CityID)
               .OnDelete(DeleteBehavior.NoAction)
               .HasConstraintName("FK_RestaurantState_RestaurantLocation");
            });
            modelBuilder.Entity<Domain.Entities.RestaurantMenuItemType>(entity =>
            {
                entity.ToTable("RestaurantMenuItemType");
                entity.HasKey(e => e.MenuItemTypeID);
                entity.Property(e => e.ItemType)
                      .IsRequired()
                      .HasMaxLength(50);
            });
            modelBuilder.Entity<Domain.Entities.RestaurantMenuItems>(entity =>
            {
                entity.ToTable("RestaurantMenuItems");
                entity.HasKey(e => e.ItemID);
                entity.Property(e => e.ItemName)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.Property(e => e.ItemPrice)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.HasOne(e => e.MenuItemType)
                .WithMany(p => p.MenuItems)
                .HasForeignKey(e => e.MenuItemTypeID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_RestaurantMenuItemType_RestaurantMenuItems");



            });
            modelBuilder.Entity<Domain.Entities.RestaurantMenu>(entity =>
            {
                entity.ToTable("RestaurantMenu");
                entity.HasKey(e => e.MenuID);
                entity.HasOne(e => e.MenuItems)
                .WithMany(p => p.Menu)
                .HasForeignKey(e => e.ItemID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_RestaurantMenuItems_RestaurantMenu");
            });
            modelBuilder.Entity<Domain.Entities.RestaurantDetails>(entity =>
            {
                entity.ToTable("RestaurantDetails");
                entity.HasKey(e => e.RestaurantID);
                entity.Property(e => e.Restaurant)
                      .IsRequired()
                      .HasMaxLength(50);
                entity.Property(e => e.Specialities)
                     .IsRequired()
                     .HasMaxLength(225);
                entity.Property(e => e.AdditionalFeatures)
                     .IsRequired()
                     .HasMaxLength(225);
                entity.HasOne(e => e.Location)
                .WithMany(p => p.RestaurantDetails)
                .HasForeignKey(e => e.LocationID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_RestaurantLocation_RestaurantDetails");
                entity.HasOne(e => e.Menu)
               .WithMany(p => p.RestaurantDetails)
               .HasForeignKey(e => e.MenuID)
               .OnDelete(DeleteBehavior.NoAction)
               .HasConstraintName("FK_RestaurantMenu_RestaurantDetails");
                entity.HasOne(e => e.Users)
               .WithMany(p => p.RestaurantDetails)
               .HasForeignKey(e => e.UserID)
               .OnDelete(DeleteBehavior.NoAction)
               .HasConstraintName("FK_Users_RestaurantDetails");
            });
            modelBuilder.Entity<User_Roles>(entity =>
            {
                entity.ToTable("User_Role");
                entity.HasKey(e => e.User_RolesID);
                entity.HasOne(d => d.Users)
                .WithMany(p => p.User_Role)
                .HasForeignKey(d => d.UserID)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK_UserRole_User");
               /* entity.HasOne(d => d.Role)
                .WithMany(p => p.User_Role)
                .HasForeignKey(d => d.RoleID)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK_UserRole_Role");*/
            });
        }
    }

}
